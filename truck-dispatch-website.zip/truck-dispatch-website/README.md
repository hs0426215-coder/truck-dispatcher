# BlueLine Dispatch - Truck Dispatching Website

A full-stack truck dispatching site: public marketing pages, driver and admin dashboards, a Node/Express API and MongoDB.

- **Frontend:** HTML5, CSS3, vanilla JavaScript (no build step)
- **Backend:** Node.js 18+, Express, Mongoose (MongoDB), JWT auth, bcrypt, Multer uploads, Nodemailer
- **Theme:** primary `#005BFF`, black `#080B12`, navy `#101827`, accent `#00A3FF`, white text

## Folder structure

```
truck-dispatch-website/
├── frontend/
│   ├── index.html  about.html  services.html  contact.html
│   ├── login.html  register.html
│   ├── driver-dashboard.html  admin-dashboard.html
│   ├── css/  style.css (public site)  dashboard.css (dashboards)
│   ├── js/   api.js (API client + session)  script.js (public site)  auth.js
│   │         ui.js (dashboard helpers)  admin.js  driver.js
│   ├── images/  (SVG truck illustrations + favicon)
│   └── sitemap.xml  robots.txt
├── backend/
│   ├── server.js  seed.js  package.json  .env.example
│   ├── config/db.js
│   ├── models/       User, Load, Inquiry, Customer, Service, Content
│   ├── controllers/  auth, public, driver, load, admin
│   ├── routes/       authRoutes, publicRoutes, driverRoutes, adminRoutes
│   ├── middleware/   auth (JWT + roles), validators, upload, error
│   ├── utils/        asyncHandler, crudFactory, mailer
│   └── uploads/      driver documents (private, never served statically)
└── README.md
```

## Run it

1. Install Node 18+ and MongoDB (local, or a free MongoDB Atlas cluster).
2. Set up the backend:
   ```bash
   cd backend
   npm install
   cp .env.example .env      # then edit .env (JWT_SECRET, MONGO_URI, ADMIN_EMAIL/PASSWORD)
   npm start                 # or: npm run dev
   ```
3. Open http://localhost:5000 - Express serves the `frontend/` folder and the API from one origin, so there is nothing else to configure.

On first start the server creates the admin account from `ADMIN_EMAIL` / `ADMIN_PASSWORD`, the nine default services and the default site content. **Change the admin password before going live.**

Hosting the frontend somewhere else? Add `<script>window.API_BASE='https://api.yourdomain.com'</script>` before `js/api.js` on each page and set `CLIENT_URL` in `.env` to the frontend's origin.

## How the roles work

| Role | How to get it | Lands on |
|---|---|---|
| Driver | Public registration (`/register.html`). Starts as **pending**. | `driver-dashboard.html` |
| Admin | Created by the seed from `.env`. Cannot be created through the public form. | `admin-dashboard.html` |

Drivers can edit their profile, submit truck info and upload documents while pending. **They can only request loads after an admin approves them.** A driver's request puts the load in `requested`; the admin moves it to `booked`, `in_transit`, `delivered` and the driver gets an email on each change.

## API overview

Public
- `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`
- `POST /api/contact` (validated, rate limited, emails the dispatch team)
- `GET /api/services`, `GET /api/content`

Driver (`Authorization: Bearer <token>`, role `driver`)
- `PUT /api/driver/profile`, `PUT /api/driver/truck`
- `POST /api/driver/documents` (multipart), `GET|DELETE /api/driver/documents/:id`
- `GET /api/driver/loads`, `POST /api/driver/loads/:id/book`
- `GET /api/driver/my-loads`, `POST /api/driver/my-loads/:id/cancel`
- `POST /api/driver/messages`

Admin (role `admin`)
- `GET /api/admin/stats`
- `/api/admin/drivers` (list, approve/suspend, delete, download documents)
- `/api/admin/loads`, `/api/admin/customers`, `/api/admin/services` (full CRUD)
- `/api/admin/inquiries` (list, mark read/replied, delete)
- `GET|PUT /api/admin/content` (hero text, phone, email, WhatsApp, address)

## Security notes

- Passwords hashed with bcrypt (12 rounds); JWT sessions; the same error for unknown email and wrong password.
- Every `/api/admin/*` route requires a valid token **and** the `admin` role; driver routes require the `driver` role.
- Input validation with express-validator; Mongoose schema validation; centralized error handler.
- Helmet with a strict Content-Security-Policy (no inline scripts), rate limiting on the API, login/register and the contact form, a honeypot field on the contact form.
- Uploaded documents are random-named, limited to PDF/JPG/PNG up to 5 MB, and only downloadable by the owner or an admin.
- The session token is kept in `localStorage`. That is simple and works well with the CSP, but if you later add third-party scripts, consider moving to httpOnly cookies.
- For production: use HTTPS (then remove `upgradeInsecureRequests: null` in `server.js`), set `NODE_ENV=production`, use a long random `JWT_SECRET`, and back up the `uploads/` folder.

## Things to replace before launch

- Company name, phone, email, WhatsApp number and address (editable in **Admin > Website content**; static fallbacks are in the HTML).
- Statistics on the home page (`data-count` values in `index.html`), testimonials, FAQ answers and team names. They are **placeholder copy**, not real figures.
- The truck images are vector illustrations in `frontend/images/`. Swap in licensed photos by replacing the files (keep the names) or editing the `<img>` tags.
- The domain in the canonical URLs, `sitemap.xml` and `robots.txt` (`https://www.yourcompany.com`).
- Social media links in the footer.
- Email: set the `SMTP_*` values in `.env`. Without them, emails are logged to the console instead of sent.
