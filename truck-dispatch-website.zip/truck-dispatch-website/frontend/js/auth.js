/* auth.js - login and registration forms */
(function () {
  const $ = (s) => document.querySelector(s);
  const alertBox = $('#authAlert');

  // Already logged in? Skip straight to the dashboard.
  const existing = BL.getUser();
  if (existing && BL.getToken()) location.replace(BL.homeFor(existing.role));

  function wire(form, endpoint, validate) {
    if (!form) return;
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      BL.clearErrors(form); BL.hideAlert(alertBox);
      if (!validate(form.elements)) { form.querySelector('.invalid input')?.focus(); return; }
      const btn = form.querySelector('button[type=submit]'), label = btn.textContent;
      btn.disabled = true; btn.textContent = 'Please wait...';
      try {
        const body = Object.fromEntries(new FormData(form).entries());
        const { token, user } = await BL.api(endpoint, { method: 'POST', body });
        BL.setSession(token, user);
        location.href = BL.homeFor(user.role);
      } catch (err) {
        BL.showServerErrors(form, err.errors); BL.showAlert(alertBox, 'err', err.message);
        btn.disabled = false; btn.textContent = label;
      }
    });
  }

  wire($('#loginForm'), '/auth/login', (f) => {
    let ok = true;
    if (!BL.EMAIL_RX.test(f.email.value.trim())) { BL.setFieldError(f.email, 'Enter a valid email address.'); ok = false; }
    if (!f.password.value) { BL.setFieldError(f.password, 'Enter your password.'); ok = false; }
    return ok;
  });

  wire($('#registerForm'), '/auth/register', (f) => {
    let ok = true; const bad = (el, m) => { BL.setFieldError(el, m); ok = false; };
    if (f.name.value.trim().length < 2) bad(f.name, 'Enter your full name.');
    if (!BL.EMAIL_RX.test(f.email.value.trim())) bad(f.email, 'Enter a valid email address.');
    if (f.phone.value && !/^[+()\-.\s\d]{7,20}$/.test(f.phone.value)) bad(f.phone, 'Enter a valid phone number.');
    const p = f.password.value;
    if (p.length < 8 || !/[A-Za-z]/.test(p) || !/\d/.test(p)) bad(f.password, 'Use 8+ characters with letters and numbers.');
    return ok;
  });
})();
