/* ==========================================================================
   api.js - shared API client + session helpers (loaded on every page)
   Set window.API_BASE before this file if the API runs on another origin,
   e.g. <script>window.API_BASE = 'https://api.yourcompany.com'</script>
   ========================================================================== */
(function () {
  const BASE = (window.API_BASE || '') + '/api';
  const TOKEN_KEY = 'bl_token';
  const USER_KEY = 'bl_user';

  const getToken = () => localStorage.getItem(TOKEN_KEY);
  const getUser = () => { try { return JSON.parse(localStorage.getItem(USER_KEY)); } catch { return null; } };
  const setSession = (token, user) => { localStorage.setItem(TOKEN_KEY, token); localStorage.setItem(USER_KEY, JSON.stringify(user)); };
  const clearSession = () => { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); };

  // Fetch wrapper: JSON in/out, attaches the JWT, turns errors into thrown Error objects
  async function api(path, { method = 'GET', body, form } = {}) {
    const headers = {};
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
    const opts = { method, headers };
    if (form) opts.body = form;                       // FormData (file upload)
    else if (body !== undefined) { headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }

    let res;
    try { res = await fetch(BASE + path, opts); }
    catch { throw Object.assign(new Error('Cannot reach the server. Check your connection and try again.'), { network: true }); }

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      // Expired / invalid session on a protected page: send the user to log in
      if (res.status === 401 && token) { clearSession(); if (!/login\.html/.test(location.pathname)) location.href = 'login.html'; }
      throw Object.assign(new Error(data.message || 'Something went wrong.'), { status: res.status, errors: data.errors });
    }
    return data;
  }

  // Download a protected file (documents) using the auth header
  async function download(path, filename) {
    const res = await fetch(BASE + path, { headers: { Authorization: `Bearer ${getToken()}` } });
    if (!res.ok) throw new Error('Could not download the file.');
    const url = URL.createObjectURL(await res.blob());
    const a = Object.assign(document.createElement('a'), { href: url, download: filename || 'document' });
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  // Where each role lands after login
  const homeFor = (role) => (role === 'admin' ? 'admin-dashboard.html' : 'driver-dashboard.html');

  // ---- Form helpers (client-side validation + server error display) ----
  const EMAIL_RX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  function setFieldError(input, msg) {
    const field = input.closest('.field'); if (!field) return;
    field.classList.toggle('invalid', !!msg);
    const out = field.querySelector('.field-error'); if (out) out.textContent = msg || '';
    input.setAttribute('aria-invalid', msg ? 'true' : 'false');
  }
  function clearErrors(form) { form.querySelectorAll('input,select,textarea').forEach((i) => setFieldError(i, '')); }
  function showServerErrors(form, errors = []) {
    errors.forEach((e) => { const el = form.elements[e.field]; if (el) setFieldError(el, e.message); });
  }
  function showAlert(el, type, msg) {
    if (!el) return;
    el.className = `alert alert--${type} show`; el.textContent = msg;
  }
  function hideAlert(el) { if (el) el.className = 'alert'; }

  window.BL = { api, download, getToken, getUser, setSession, clearSession, homeFor, EMAIL_RX, setFieldError, clearErrors, showServerErrors, showAlert, hideAlert };
})();
