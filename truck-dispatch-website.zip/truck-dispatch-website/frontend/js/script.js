/* ==========================================================================
   script.js - public website behaviour
   loader, mobile menu, sticky header, reveal, counters, slider,
   editable content, services from API, contact form
   ========================================================================== */
(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (s = '') => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ---- Loading animation: hide as soon as the page is ready ---- */
  const hideLoader = () => { const l = $('#loader'); if (l) { l.classList.add('done'); setTimeout(() => l.remove(), 500); } };
  if (document.readyState === 'complete') hideLoader(); else window.addEventListener('load', () => setTimeout(hideLoader, 250));

  const year = $('#year'); if (year) year.textContent = new Date().getFullYear();

  /* ---- Sticky header shadow ---- */
  const header = $('#header');
  const onScroll = () => header && header.classList.toggle('scrolled', window.scrollY > 10);
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  /* ---- Mobile navigation ---- */
  const toggle = $('#navToggle'), panel = $('#navPanel');
  if (toggle && panel) {
    const setOpen = (open) => { panel.classList.toggle('open', open); toggle.setAttribute('aria-expanded', open); toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu'); document.body.style.overflow = open && innerWidth <= 860 ? 'hidden' : ''; };
    toggle.addEventListener('click', () => setOpen(!panel.classList.contains('open')));
    panel.addEventListener('click', (e) => { if (e.target.closest('a')) setOpen(false); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setOpen(false); });
    window.addEventListener('resize', () => { if (innerWidth > 860) setOpen(false); });
  }

  /* ---- If logged in, swap the login buttons for a dashboard link ---- */
  const user = window.BL && BL.getUser();
  if (user && BL.getToken()) {
    const cta = $('.nav__cta');
    if (cta) cta.innerHTML = `<a class="btn btn--primary btn--sm" href="${BL.homeFor(user.role)}">My dashboard</a>`;
  }

  /* ---- Scroll reveal (opacity) ---- */
  const reveals = $$('.reveal');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12 });
    reveals.forEach((el, i) => { el.style.transitionDelay = `${(i % 3) * 80}ms`; io.observe(el); });
  } else reveals.forEach((el) => el.classList.add('in'));

  /* ---- Animated statistics ---- */
  const counters = $$('[data-count]');
  const run = (el) => {
    const target = +el.dataset.count, dur = 1600, start = performance.now();
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = target.toLocaleString(); return; }
    const tick = (t) => { const p = Math.min((t - start) / dur, 1); el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3))).toLocaleString(); if (p < 1) requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  };
  if ('IntersectionObserver' in window) {
    const co = new IntersectionObserver((entries) => entries.forEach((e) => { if (e.isIntersecting) { run(e.target); co.unobserve(e.target); } }), { threshold: .6 });
    counters.forEach((c) => co.observe(c));
  }

  /* ---- Testimonials slider ---- */
  const slider = $('#slider');
  if (slider) {
    const slides = $$('.slide', slider), dots = $$('.dots button', slider);
    let i = 0, timer;
    const show = (n) => { i = (n + slides.length) % slides.length; slides.forEach((s, k) => s.classList.toggle('active', k === i)); dots.forEach((d, k) => d.classList.toggle('active', k === i)); };
    const auto = () => { clearInterval(timer); if (!matchMedia('(prefers-reduced-motion: reduce)').matches) timer = setInterval(() => show(i + 1), 6000); };
    dots.forEach((d, k) => d.addEventListener('click', () => { show(k); auto(); }));
    slider.addEventListener('mouseenter', () => clearInterval(timer)); slider.addEventListener('mouseleave', auto); auto();
  }

  /* ---- Editable content + services from the API (page keeps its static copy if the API is offline) ---- */
  const waLink = (num, text) => `https://wa.me/${String(num).replace(/\D/g, '')}${text ? `?text=${encodeURIComponent(text)}` : ''}`;
  async function loadContent() {
    try {
      const c = await BL.api('/content');
      $$('[data-content]').forEach((el) => { if (c[el.dataset.content]) el.textContent = c[el.dataset.content]; });
      $$('[data-link]').forEach((el) => {
        const [kind, key] = el.dataset.link.split(':'); const v = c[key]; if (!v) return;
        if (kind === 'tel') el.href = `tel:${v.replace(/[^\d+]/g, '')}`;
        if (kind === 'mailto') el.href = `mailto:${v}`;
        if (kind === 'wa') el.href = waLink(v, el.href.includes('text=') ? 'Hi BlueLine Dispatch, I need a dispatcher.' : '');
      });
    } catch { /* offline: static text stays */ }
  }
  async function loadServices() {
    const grid = $('#services-grid'); if (!grid) return;
    try {
      let list = await BL.api('/services');
      if (!list.length) return;
      if (grid.dataset.limit) list = list.slice(0, +grid.dataset.limit);
      grid.innerHTML = list.map((s) => `<article class="card in"><div class="card__icon"><svg class="icon" aria-hidden="true"><use href="#i-${esc(s.icon || 'truck')}"/></svg></div><h3>${esc(s.title)}</h3><p>${esc(s.description)}</p></article>`).join('');
    } catch { /* keep static cards */ }
  }
  loadContent(); loadServices();

  /* ---- Contact form ---- */
  const form = $('#contactForm');
  if (form) {
    const alertBox = $('#contactAlert');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      BL.clearErrors(form); BL.hideAlert(alertBox);
      const f = form.elements; let ok = true;
      const bad = (el, msg) => { BL.setFieldError(el, msg); ok = false; };
      if (f.name.value.trim().length < 2) bad(f.name, 'Enter your name.');
      if (!BL.EMAIL_RX.test(f.email.value.trim())) bad(f.email, 'Enter a valid email address.');
      if (f.phone.value && !/^[+()\-.\s\d]{7,20}$/.test(f.phone.value)) bad(f.phone, 'Enter a valid phone number.');
      if (f.message.value.trim().length < 10) bad(f.message, 'Tell us a little more (at least 10 characters).');
      if (!ok) { form.querySelector('.invalid input, .invalid textarea')?.focus(); return; }
      if (f.website.value) return;                       // honeypot filled: silently drop bots

      const btn = form.querySelector('button[type=submit]'); btn.disabled = true; btn.textContent = 'Sending...';
      try {
        const res = await BL.api('/contact', { method: 'POST', body: { name: f.name.value.trim(), email: f.email.value.trim(), phone: f.phone.value.trim(), subject: f.subject.value, message: f.message.value.trim() } });
        BL.showAlert(alertBox, 'ok', res.message); form.reset();
      } catch (err) {
        BL.showServerErrors(form, err.errors); BL.showAlert(alertBox, 'err', err.message);
      } finally { btn.disabled = false; btn.textContent = 'Send message'; }
    });
  }
})();
