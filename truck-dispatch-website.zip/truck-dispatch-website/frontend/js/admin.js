/* ==========================================================================
   admin.js - admin dashboard (stats, drivers, loads, customers, messages,
   services, website content). All data comes from /api/admin/* (JWT + admin role).
   ========================================================================== */
(function () {
  const { esc, money, date, dateInput, EQUIP, DOCS, badge, toast, openForm, openInfo, confirmBox, table, debounce } = UI;
  const opts = (obj) => Object.entries(obj);
  const LOAD_STATUS = [['available', 'Available'], ['requested', 'Requested by driver'], ['booked', 'Booked'], ['in_transit', 'In transit'], ['delivered', 'Delivered'], ['cancelled', 'Cancelled']];
  const ICONS = ['van', 'snow', 'flatbed', 'stepdeck', 'clipboard', 'route', 'dollar', 'chat', 'clock', 'truck', 'shield', 'users'].map((i) => [i, i]);

  /* ---------- generic list + add/edit/delete view ---------- */
  function crudView({ endpoint, noun, columns, fields, filters = [], toValues = (r) => r, empty }) {
    return async (view) => {
      const state = {};
      view.innerHTML = `<div class="toolbar">${filters.map((f) => f.type === 'search'
        ? `<input type="search" data-filter="q" placeholder="${esc(f.placeholder)}" aria-label="${esc(f.placeholder)}">`
        : `<select data-filter="${f.name}" aria-label="${esc(f.label)}"><option value="">${esc(f.label)}</option>${f.options.map(([k, t]) => `<option value="${k}">${esc(t)}</option>`).join('')}</select>`).join('')}
        <span class="grow"></span><button class="btn btn--primary btn--sm" id="addBtn">Add ${noun}</button></div><div id="list"></div>`;
      const list = view.querySelector('#list'); let rows = [];

      const render = () => {
        const cols = [...columns, { label: '', render: (r) => `<div class="actions"><button class="btn btn--ghost btn--sm" data-act="edit" data-id="${r._id}">Edit</button><button class="btn btn--danger btn--sm" data-act="del" data-id="${r._id}">Delete</button></div>` }];
        list.innerHTML = table(cols, rows, empty);
      };
      const load = async () => { rows = await BL.api(`${endpoint}?${new URLSearchParams(state)}`); render(); };

      view.querySelectorAll('[data-filter]').forEach((el) => el.addEventListener(el.type === 'search' ? 'input' : 'change', debounce(() => { state[el.dataset.filter] = el.value; if (!el.value) delete state[el.dataset.filter]; load().catch((e) => toast(e.message, 'err')); }, 250)));

      view.querySelector('#addBtn').onclick = () => openForm({ title: `Add ${noun}`, fields: fields('create'), submitLabel: `Add ${noun}`, onSubmit: async (v) => { await BL.api(endpoint, { method: 'POST', body: v }); toast(`${noun} added`); load(); } });

      list.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-act]'); if (!b) return;
        const row = rows.find((r) => r._id === b.dataset.id);
        if (b.dataset.act === 'edit') {
          openForm({ title: `Edit ${noun}`, fields: fields('edit').map((f) => ({ ...f, keepEmpty: true })), values: toValues(row), onSubmit: async (v) => { await BL.api(`${endpoint}/${row._id}`, { method: 'PUT', body: v }); toast(`${noun} updated`); load(); } });
        } else if (await confirmBox(`Delete this ${noun.toLowerCase()}? This cannot be undone.`)) {
          try { await BL.api(`${endpoint}/${row._id}`, { method: 'DELETE' }); toast(`${noun} deleted`); load(); } catch (err) { toast(err.message, 'err'); }
        }
      });
      await load();
    };
  }

  /* ---------- overview ---------- */
  async function overview(view) {
    const s = await BL.api('/admin/stats');
    const kpi = (n, l, c = '') => `<div class="kpi ${c}"><b>${n}</b><span>${l}</span></div>`;
    view.innerHTML = `<div class="kpis">
      ${kpi(s.drivers, 'Registered drivers')}${kpi(s.pendingDrivers, 'Awaiting approval', 'kpi--warn')}${kpi(s.availableLoads, 'Available loads')}${kpi(s.activeLoads, 'Loads in progress')}
      ${kpi(s.delivered, 'Delivered loads', 'kpi--ok')}${kpi(money(s.deliveredRevenue), 'Delivered load value', 'kpi--ok')}${kpi(s.customers, 'Customers')}${kpi(s.newMessages, 'New messages', 'kpi--warn')}</div>
      <div class="cols"><div class="panel"><h2>Recent loads</h2>${table([{ label: 'Load', render: (r) => `${esc(r.loadNumber)}<span class="sub">${esc(r.origin)} to ${esc(r.destination)}</span>` }, { label: 'Rate', render: (r) => money(r.rate) }, { label: 'Status', render: (r) => badge(r.status) }], s.recentLoads, 'No loads yet. Add your first load.')}</div>
      <div class="panel"><h2>Newest drivers</h2>${table([{ label: 'Driver', render: (r) => `${esc(r.name)}<span class="sub">${esc(r.email)}</span>` }, { label: 'Joined', render: (r) => date(r.createdAt) }, { label: 'Status', render: (r) => badge(r.status) }], s.recentDrivers, 'No drivers yet.')}</div></div>`;
  }

  /* ---------- drivers ---------- */
  async function drivers(view) {
    view.innerHTML = `<div class="toolbar"><input type="search" id="q" placeholder="Search name, email, company or MC" aria-label="Search drivers"><select id="st" aria-label="Status"><option value="">All statuses</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="suspended">Suspended</option></select></div><div id="list"></div>`;
    const list = view.querySelector('#list'); let rows = [];
    const render = () => {
      list.innerHTML = table([
        { label: 'Driver', render: (r) => `${esc(r.name)}<span class="sub">${esc(r.email)}${r.phone ? ` &middot; ${esc(r.phone)}` : ''}</span>` },
        { label: 'Company', render: (r) => `${esc(r.companyName || '-')}<span class="sub">MC ${esc(r.mcNumber || '-')} &middot; DOT ${esc(r.dotNumber || '-')}</span>` },
        { label: 'Truck', render: (r) => esc(EQUIP[r.truck?.type] || '-') },
        { label: 'Docs', render: (r) => r.documents.length },
        { label: 'Joined', render: (r) => date(r.createdAt) },
        { label: 'Status', render: (r) => badge(r.status) },
        { label: '', render: (r) => `<div class="actions"><button class="btn btn--ghost btn--sm" data-act="view" data-id="${r._id}">View</button>${r.status !== 'approved' ? `<button class="btn btn--primary btn--sm" data-act="approved" data-id="${r._id}">Approve</button>` : `<button class="btn btn--ghost btn--sm" data-act="suspended" data-id="${r._id}">Suspend</button>`}<button class="btn btn--danger btn--sm" data-act="del" data-id="${r._id}">Delete</button></div>` },
      ], rows, 'No drivers match.');
    };
    const load = async () => { rows = await BL.api(`/admin/drivers?${new URLSearchParams({ q: view.querySelector('#q').value, status: view.querySelector('#st').value })}`); render(); };
    view.querySelector('#q').addEventListener('input', debounce(() => load().catch((e) => toast(e.message, 'err'))));
    view.querySelector('#st').addEventListener('change', () => load());

    list.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-act]'); if (!b) return;
      const d = rows.find((r) => r._id === b.dataset.id); const act = b.dataset.act;
      try {
        if (act === 'view') {
          const t = d.truck || {};
          const bg = openInfo(d.name, `<ul class="info-list"><li><div><b>Contact</b><span>${esc(d.email)} ${d.phone ? `&middot; ${esc(d.phone)}` : ''}</span></div></li>
            <li><div><b>Company</b><span>${esc(d.companyName || '-')} &middot; MC ${esc(d.mcNumber || '-')} &middot; DOT ${esc(d.dotNumber || '-')}</span></div></li>
            <li><div><b>Truck</b><span>${t.type ? `${esc(EQUIP[t.type])} &middot; ${esc([t.year, t.make, t.model].filter(Boolean).join(' '))} &middot; Plate ${esc(t.plate || '-')} &middot; ${t.trailerLengthFt ? `${t.trailerLengthFt} ft` : ''} ${t.capacityLbs ? `${Number(t.capacityLbs).toLocaleString()} lb` : ''}` : 'Not submitted'}</span>${t.preferredLanes ? `<span class="sub">Preferred lanes: ${esc(t.preferredLanes)}</span>` : ''}</div></li>
            <li><div><b>Status</b>${badge(d.status)}</div></li>
            <li><div><b>Documents</b>${d.documents.length ? d.documents.map((x) => `<button class="btn btn--ghost btn--sm" style="margin:4px 6px 0 0" data-doc="${x._id}" data-name="${esc(x.originalName)}">${esc(DOCS[x.type])}: ${esc(x.originalName)}</button>`).join('') : '<span>None uploaded</span>'}</div></li></ul>`);
          bg.addEventListener('click', (ev) => { const doc = ev.target.closest('[data-doc]'); if (doc) BL.download(`/admin/drivers/${d._id}/documents/${doc.dataset.doc}`, doc.dataset.name).catch((er) => toast(er.message, 'err')); });
        } else if (act === 'del') {
          if (await confirmBox(`Delete ${d.name} and their documents? Their pending load requests return to available.`)) { await BL.api(`/admin/drivers/${d._id}`, { method: 'DELETE' }); toast('Driver deleted'); load(); }
        } else { await BL.api(`/admin/drivers/${d._id}`, { method: 'PATCH', body: { status: act } }); toast(`Driver ${act}`); load(); }
      } catch (err) { toast(err.message, 'err'); }
    });
    await load();
  }

  /* ---------- loads ---------- */
  const loads = crudView({
    endpoint: '/admin/loads', noun: 'Load', empty: 'No loads yet. Add your first load.',
    filters: [{ type: 'search', placeholder: 'Search load #, city or broker' }, { name: 'status', label: 'All statuses', options: LOAD_STATUS }, { name: 'equipment', label: 'All equipment', options: opts(EQUIP) }],
    columns: [
      { label: 'Load', render: (r) => `<b>${esc(r.loadNumber)}</b><span class="sub">${esc(r.commodity || '')}</span>` },
      { label: 'Lane', render: (r) => `${esc(r.origin)} &rarr; ${esc(r.destination)}<span class="sub">${r.miles ? `${Number(r.miles).toLocaleString()} mi` : ''}</span>` },
      { label: 'Pickup', render: (r) => date(r.pickupDate) },
      { label: 'Equipment', render: (r) => esc(EQUIP[r.equipment]) },
      { label: 'Rate', render: (r) => money(r.rate) },
      { label: 'Driver', render: (r) => (r.bookedBy ? `${esc(r.bookedBy.name)}<span class="sub">${esc(r.bookedBy.phone || r.bookedBy.email)}</span>` : '-') },
      { label: 'Status', render: (r) => badge(r.status) },
    ],
    fields: (mode) => [
      { name: 'origin', label: 'Origin (city, state)', required: true }, { name: 'destination', label: 'Destination (city, state)', required: true },
      { name: 'pickupDate', label: 'Pickup date', type: 'date', required: true }, { name: 'deliveryDate', label: 'Delivery date', type: 'date' },
      { name: 'equipment', label: 'Equipment', type: 'select', options: opts(EQUIP), required: true }, { name: 'rate', label: 'Rate (USD)', type: 'number', step: '1', required: true },
      { name: 'miles', label: 'Miles', type: 'number' }, { name: 'weightLbs', label: 'Weight (lb)', type: 'number' },
      { name: 'commodity', label: 'Commodity' }, { name: 'broker', label: 'Broker' },
      ...(mode === 'edit' ? [{ name: 'status', label: 'Status', type: 'select', options: LOAD_STATUS, full: true }] : []),
      { name: 'notes', label: 'Notes', type: 'textarea', full: true },
    ],
    toValues: (r) => ({ ...r, pickupDate: dateInput(r.pickupDate), deliveryDate: dateInput(r.deliveryDate) }),
  });

  /* ---------- customers ---------- */
  const customers = crudView({
    endpoint: '/admin/customers', noun: 'Customer', empty: 'No customers yet. Add the brokers and shippers you work with.',
    filters: [{ type: 'search', placeholder: 'Search name, company or email' }],
    columns: [
      { label: 'Name', render: (r) => `<b>${esc(r.name)}</b><span class="sub">${esc(r.company || '')}</span>` },
      { label: 'Contact', render: (r) => `${esc(r.email || '-')}<span class="sub">${esc(r.phone || '')}</span>` },
      { label: 'Type', render: (r) => esc(r.type) }, { label: 'Status', render: (r) => badge(r.status) },
    ],
    fields: () => [
      { name: 'name', label: 'Contact name', required: true }, { name: 'company', label: 'Company' },
      { name: 'email', label: 'Email', type: 'email' }, { name: 'phone', label: 'Phone', type: 'tel' },
      { name: 'type', label: 'Type', type: 'select', options: [['broker', 'Broker'], ['shipper', 'Shipper'], ['carrier', 'Carrier']] },
      { name: 'status', label: 'Status', type: 'select', options: [['active', 'Active'], ['inactive', 'Inactive']] },
      { name: 'notes', label: 'Notes', type: 'textarea', full: true },
    ],
  });

  /* ---------- services ---------- */
  const services = crudView({
    endpoint: '/admin/services', noun: 'Service', empty: 'No services yet.',
    columns: [
      { label: 'Order', render: (r) => r.order }, { label: 'Service', render: (r) => `<b>${esc(r.title)}</b><span class="sub">${esc(r.description)}</span>` },
      { label: 'Icon', render: (r) => esc(r.icon) }, { label: 'Visible', render: (r) => (r.active ? badge('active') : badge('inactive')) },
    ],
    fields: () => [
      { name: 'title', label: 'Title', required: true, full: true }, { name: 'description', label: 'Description', type: 'textarea', required: true, full: true },
      { name: 'icon', label: 'Icon', type: 'select', options: ICONS }, { name: 'order', label: 'Display order', type: 'number' },
      { name: 'active', label: 'Show on website', type: 'checkbox' },
    ],
  });

  /* ---------- messages ---------- */
  async function messages(view) {
    view.innerHTML = `<div class="toolbar"><select id="st" aria-label="Status"><option value="">All messages</option><option value="new">New</option><option value="read">Read</option><option value="replied">Replied</option></select></div><div class="table-wrap" id="list"></div>`;
    const list = view.querySelector('#list'); let rows = [];
    const render = () => {
      list.innerHTML = rows.length ? rows.map((m) => `<article class="msg${m.status === 'new' ? ' unread' : ''}"><div class="msg__head"><b>${esc(m.name)}</b>${badge(m.status)}<span class="muted">${esc(m.subject)} &middot; ${m.source === 'driver' ? 'Driver' : 'Website'} &middot; ${date(m.createdAt)}</span></div>
        <span class="muted">${esc(m.email)}${m.phone ? ` &middot; ${esc(m.phone)}` : ''}</span><p class="msg__body">${esc(m.message)}</p>
        <div class="actions"><a class="btn btn--primary btn--sm" href="mailto:${esc(m.email)}?subject=${encodeURIComponent(`Re: ${m.subject}`)}" data-act="replied" data-id="${m._id}">Reply by email</a>${m.status === 'new' ? `<button class="btn btn--ghost btn--sm" data-act="read" data-id="${m._id}">Mark read</button>` : ''}${m.status !== 'replied' ? `<button class="btn btn--ghost btn--sm" data-act="replied" data-id="${m._id}">Mark replied</button>` : ''}<button class="btn btn--danger btn--sm" data-act="del" data-id="${m._id}">Delete</button></div></article>`).join('')
        : '<div class="empty">No messages.</div>';
    };
    const load = async () => { rows = await BL.api(`/admin/inquiries?${new URLSearchParams({ status: view.querySelector('#st').value })}`); render(); };
    view.querySelector('#st').onchange = load;
    list.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-act]'); if (!b) return;
      try {
        if (b.dataset.act === 'del') { if (!(await confirmBox('Delete this message?'))) return; await BL.api(`/admin/inquiries/${b.dataset.id}`, { method: 'DELETE' }); }
        else await BL.api(`/admin/inquiries/${b.dataset.id}`, { method: 'PATCH', body: { status: b.dataset.act } });
        if (b.tagName === 'BUTTON' || b.dataset.act === 'del') load(); else setTimeout(load, 400);   // mailto link opens the mail app, then refresh
      } catch (err) { toast(err.message, 'err'); }
    });
    await load();
  }

  /* ---------- website content ---------- */
  async function content(view) {
    const c = await BL.api('/admin/content');
    const fields = [
      { name: 'heroTitle', label: 'Home page headline', full: true }, { name: 'heroSubtitle', label: 'Home page subtitle', type: 'textarea', full: true },
      { name: 'phone', label: 'Phone number' }, { name: 'email', label: 'Business email', type: 'email' },
      { name: 'whatsapp', label: 'WhatsApp number (digits with country code, e.g. 15551234567)' }, { name: 'address', label: 'Office address' },
    ];
    view.innerHTML = `<div class="panel" style="max-width:760px"><h2>Website content</h2><p>Changes appear on the public site as soon as you save.</p><form class="form form--2" id="cf" novalidate>${fields.map((f) => `<div class="field${f.full ? ' field--full' : ''}"><label for="f-${f.name}">${esc(f.label)}</label>${f.type === 'textarea' ? `<textarea id="f-${f.name}" name="${f.name}">${esc(c[f.name] || '')}</textarea>` : `<input id="f-${f.name}" name="${f.name}" type="${f.type || 'text'}" value="${esc(c[f.name] || '')}">`}</div>`).join('')}<div class="field--full"><button class="btn btn--primary" type="submit">Save changes</button></div></form></div>`;
    view.querySelector('#cf').onsubmit = async (e) => {
      e.preventDefault();
      try { await BL.api('/admin/content', { method: 'PUT', body: Object.fromEntries(new FormData(e.target).entries()) }); toast('Website content saved'); } catch (err) { toast(err.message, 'err'); }
    };
  }

  const shell = UI.initShell({ role: 'admin', views: { overview, drivers, loads, customers, messages, services, content } });

  // Show counts of things that need attention in the sidebar
  if (shell) BL.api('/admin/stats').then((s) => {
    const add = (v, n) => { const el = document.querySelector(`.side-link[data-view="${v}"]`); if (el && n) el.insertAdjacentHTML('beforeend', `<span class="count">${n}</span>`); };
    add('drivers', s.pendingDrivers); add('messages', s.newMessages);
  }).catch(() => {});
})();
