/* ==========================================================================
   driver.js - driver dashboard (profile, truck, documents, loads, messages)
   All data comes from /api/driver/* (JWT + driver role).
   ========================================================================== */
(function () {
  const { esc, money, date, EQUIP, DOCS, badge, toast, table, fieldHTML, readValues, confirmBox } = UI;
  const opts = (o) => Object.entries(o);
  const REQUIRED_DOCS = ['cdl', 'mc_authority', 'insurance', 'w9'];

  // Render an inline form and wire submit -> handler(values)
  function inlineForm(view, { title, intro = '', fields, values = {}, submit = 'Save changes', onSubmit, selector = 'form' }) {
    const panel = document.createElement('div'); panel.className = 'panel'; panel.style.maxWidth = '760px';
    panel.innerHTML = `<h2>${esc(title)}</h2>${intro ? `<p>${intro}</p>` : ''}<form class="form form--2" novalidate>${fields.map((f) => fieldHTML(f, values[f.name])).join('')}<div class="field--full"><div class="alert" role="alert"></div></div><div class="field--full"><button class="btn btn--primary" type="submit">${esc(submit)}</button></div></form>`;
    view.appendChild(panel);
    const form = panel.querySelector('form'), alertBox = panel.querySelector('.alert');
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); BL.clearErrors(form); BL.hideAlert(alertBox);
      let ok = true;
      fields.forEach((f) => { if (f.required && !form.elements[f.name].value.trim()) { BL.setFieldError(form.elements[f.name], 'Required.'); ok = false; } });
      if (!ok) return;
      const btn = form.querySelector('[type=submit]'); btn.disabled = true;
      try { await onSubmit(readValues(form, fields), form); } catch (err) { BL.showServerErrors(form, err.errors); BL.showAlert(alertBox, 'err', err.message); }
      btn.disabled = false;
    });
    return form;
  }

  const statusBanner = (me) => ({
    pending: '<div class="alert alert--err show" style="background:rgba(255,176,32,.12);border-color:#ffb020;color:#ffd27a;margin-bottom:24px"><b>Your account is pending approval.</b> Add your truck details and upload your documents. You can book loads as soon as dispatch approves you.</div>',
    suspended: '<div class="alert alert--err show" style="margin-bottom:24px"><b>Your account is suspended.</b> Contact dispatch to resolve this.</div>',
    approved: '',
  }[me.status] || '');

  /* ---------- overview ---------- */
  async function overview(view) {
    const [me, mine] = await Promise.all([BL.api('/auth/me'), BL.api('/driver/my-loads')]);
    const docTypes = new Set(me.documents.map((d) => d.type));
    const items = [
      ['Profile completed', !!(me.companyName && me.mcNumber && me.dotNumber), 'profile'],
      ['Truck details submitted', !!me.truck?.type, 'truck'],
      ['Required documents uploaded (CDL, MC authority, insurance, W-9)', REQUIRED_DOCS.every((t) => docTypes.has(t)), 'documents'],
      ['Account approved by dispatch', me.status === 'approved', null],
    ];
    const active = mine.filter((l) => ['requested', 'booked', 'in_transit'].includes(l.status)).length;
    view.innerHTML = `${statusBanner(me)}<div class="kpis"><div class="kpi"><b>${active}</b><span>Loads in progress</span></div><div class="kpi kpi--ok"><b>${mine.filter((l) => l.status === 'delivered').length}</b><span>Delivered loads</span></div><div class="kpi"><b>${me.documents.length}</b><span>Documents uploaded</span></div><div class="kpi ${me.status === 'approved' ? 'kpi--ok' : 'kpi--warn'}"><b style="font-size:1.8rem;text-transform:capitalize">${esc(me.status)}</b><span>Account status</span></div></div>
      <div class="panel" style="max-width:760px"><h2>Getting started</h2><ul class="steps-list">${items.map(([t, done, v]) => `<li class="${done ? 'done' : ''}"><span class="dot">${done ? '&#10003;' : ''}</span>${v && !done ? `<a href="#${v}">${esc(t)}</a>` : esc(t)}</li>`).join('')}</ul></div>`;
  }

  /* ---------- available loads ---------- */
  async function loads(view) {
    const me = await BL.api('/auth/me');
    view.innerHTML = `${statusBanner(me)}<div class="toolbar"><select id="eq" aria-label="Equipment"><option value="">All equipment</option>${opts(EQUIP).map(([k, t]) => `<option value="${k}">${t}</option>`).join('')}</select><span class="muted">Showing loads you can request. Dispatch confirms every booking.</span></div><div class="table-wrap" id="list"></div>`;
    const list = view.querySelector('#list'); let rows = [];
    const render = () => {
      list.innerHTML = rows.length ? rows.map((l) => `<div class="load-card"><div><div class="lane">${esc(l.origin)}<i>&rarr;</i>${esc(l.destination)}</div>
        <div class="load-meta"><span>${esc(l.loadNumber)}</span><span>Pickup ${date(l.pickupDate)}</span>${l.deliveryDate ? `<span>Delivery ${date(l.deliveryDate)}</span>` : ''}<span>${esc(EQUIP[l.equipment])}</span>${l.miles ? `<span>${Number(l.miles).toLocaleString()} mi</span>` : ''}${l.weightLbs ? `<span>${Number(l.weightLbs).toLocaleString()} lb</span>` : ''}${l.commodity ? `<span>${esc(l.commodity)}</span>` : ''}</div></div>
        <div><div class="rate">${money(l.rate)}<small>${l.miles ? `$${(l.rate / l.miles).toFixed(2)} / mile` : 'total rate'}</small></div><button class="btn btn--primary btn--sm btn--block" style="margin-top:8px" data-id="${l._id}" ${me.status !== 'approved' ? 'disabled title="Available after approval"' : ''}>Request load</button></div></div>`).join('')
        : '<div class="empty">No available loads right now. Check back soon, or message dispatch with your preferred lanes.</div>';
    };
    const load = async () => { rows = await BL.api(`/driver/loads?${new URLSearchParams({ equipment: view.querySelector('#eq').value })}`); render(); };
    view.querySelector('#eq').onchange = load;
    list.addEventListener('click', async (e) => {
      const b = e.target.closest('button[data-id]'); if (!b) return;
      const l = rows.find((r) => r._id === b.dataset.id);
      if (!(await confirmBox(`Request ${l.loadNumber} (${l.origin} to ${l.destination}) for ${money(l.rate)}?`, 'Request load'))) return;
      try { await BL.api(`/driver/loads/${l._id}/book`, { method: 'POST' }); toast('Load requested. Dispatch will confirm.'); } catch (err) { toast(err.message, 'err'); }
      load();
    });
    await load();
  }

  /* ---------- my loads / booking status ---------- */
  async function mine(view) {
    const load = async () => {
      const rows = await BL.api('/driver/my-loads');
      view.innerHTML = table([
        { label: 'Load', render: (r) => `<b>${esc(r.loadNumber)}</b><span class="sub">${esc(r.commodity || '')}</span>` },
        { label: 'Lane', render: (r) => `${esc(r.origin)} &rarr; ${esc(r.destination)}` },
        { label: 'Pickup', render: (r) => date(r.pickupDate) }, { label: 'Rate', render: (r) => money(r.rate) },
        { label: 'Broker', render: (r) => (['booked', 'in_transit', 'delivered'].includes(r.status) ? esc(r.broker || '-') : 'After confirmation') },
        { label: 'Status', render: (r) => badge(r.status) },
        { label: '', render: (r) => (r.status === 'requested' ? `<button class="btn btn--danger btn--sm" data-cancel="${r._id}">Withdraw</button>` : '') },
      ], rows, 'You have not requested any loads yet. Browse available loads to get started.');
    };
    view.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-cancel]'); if (!b) return;
      try { await BL.api(`/driver/my-loads/${b.dataset.cancel}/cancel`, { method: 'POST' }); toast('Request withdrawn'); load(); } catch (err) { toast(err.message, 'err'); }
    });
    await load();
  }

  /* ---------- truck ---------- */
  async function truck(view) {
    const me = await BL.api('/auth/me'); const t = me.truck || {};
    view.innerHTML = statusBanner(me);
    inlineForm(view, {
      title: 'Truck information', intro: 'Tell us what you run so we can match the right loads.', values: t,
      fields: [
        { name: 'type', label: 'Equipment type', type: 'select', options: opts(EQUIP), placeholder: 'Choose...', required: true }, { name: 'trailerLengthFt', label: 'Trailer length (ft)', type: 'number' },
        { name: 'make', label: 'Truck make' }, { name: 'model', label: 'Truck model' },
        { name: 'year', label: 'Year', type: 'number' }, { name: 'capacityLbs', label: 'Max payload (lb)', type: 'number' },
        { name: 'plate', label: 'License plate' }, { name: 'vin', label: 'VIN' },
        { name: 'preferredLanes', label: 'Preferred lanes and minimum rate per mile', type: 'textarea', full: true, placeholder: 'e.g. TX to GA, Midwest loops. Minimum $2.40/mile.' },
      ],
      submit: 'Save truck', onSubmit: async (v) => { await BL.api('/driver/truck', { method: 'PUT', body: v }); toast('Truck information saved'); },
    });
  }

  /* ---------- documents ---------- */
  async function documents(view) {
    const draw = async () => {
      const me = await BL.api('/auth/me'); const have = new Set(me.documents.map((d) => d.type));
      view.innerHTML = `${statusBanner(me)}<div class="panel" style="max-width:760px"><h2>Upload a document</h2><p>PDF, JPG or PNG, up to 5 MB. Required: ${REQUIRED_DOCS.map((t) => `<span class="badge badge--${have.has(t) ? 'ok' : 'warn'}">${esc(DOCS[t])}${have.has(t) ? ' &#10003;' : ''}</span>`).join(' ')}</p>
        <form class="form form--2" id="up" novalidate><div class="field"><label for="d-type">Document type</label><select id="d-type" name="type">${opts(DOCS).map(([k, t]) => `<option value="${k}">${esc(t)}</option>`).join('')}</select></div>
        <div class="field"><label for="d-file">File</label><input id="d-file" name="file" type="file" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png"></div>
        <div class="field--full"><div class="alert" role="alert"></div></div><div class="field--full"><button class="btn btn--primary" type="submit">Upload document</button></div></form></div>
        <div id="docs">${table([{ label: 'Type', render: (d) => esc(DOCS[d.type]) }, { label: 'File', render: (d) => esc(d.originalName) }, { label: 'Uploaded', render: (d) => date(d.uploadedAt) },
          { label: '', render: (d) => `<div class="actions"><button class="btn btn--ghost btn--sm" data-dl="${d._id}" data-name="${esc(d.originalName)}">Download</button><button class="btn btn--danger btn--sm" data-rm="${d._id}">Remove</button></div>` }], me.documents, 'No documents uploaded yet.')}</div>`;
      const form = view.querySelector('#up'), alertBox = form.querySelector('.alert');
      form.addEventListener('submit', async (e) => {
        e.preventDefault(); BL.hideAlert(alertBox);
        const file = form.elements.file.files[0];
        if (!file) return BL.showAlert(alertBox, 'err', 'Choose a file to upload.');
        if (file.size > 5 * 1024 * 1024) return BL.showAlert(alertBox, 'err', 'That file is larger than 5 MB.');
        const btn = form.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'Uploading...';
        try { await BL.api('/driver/documents', { method: 'POST', form: new FormData(form) }); toast('Document uploaded'); draw(); }
        catch (err) { BL.showAlert(alertBox, 'err', err.message); btn.disabled = false; btn.textContent = 'Upload document'; }
      });
      view.querySelector('#docs').addEventListener('click', async (e) => {
        const dl = e.target.closest('[data-dl]'), rm = e.target.closest('[data-rm]');
        try {
          if (dl) await BL.download(`/driver/documents/${dl.dataset.dl}/file`, dl.dataset.name);
          if (rm && await confirmBox('Remove this document?', 'Remove')) { await BL.api(`/driver/documents/${rm.dataset.rm}`, { method: 'DELETE' }); toast('Document removed'); draw(); }
        } catch (err) { toast(err.message, 'err'); }
      });
    };
    await draw();
  }

  /* ---------- profile ---------- */
  async function profile(view) {
    const me = await BL.api('/auth/me'); view.innerHTML = '';
    inlineForm(view, {
      title: 'Your profile', values: me,
      fields: [{ name: 'name', label: 'Full name', required: true }, { name: 'phone', label: 'Phone', type: 'tel' }, { name: 'companyName', label: 'Company name' }, { name: 'mcNumber', label: 'MC number' }, { name: 'dotNumber', label: 'DOT number' }, { name: 'address', label: 'Address' }],
      onSubmit: async (v) => { await BL.api('/driver/profile', { method: 'PUT', body: Object.fromEntries(Object.entries(v).map(([k, x]) => [k, x ?? ''])) }); toast('Profile saved'); },
    });
    inlineForm(view, {
      title: 'Change password', submit: 'Update password',
      fields: [{ name: 'currentPassword', label: 'Current password', type: 'password', required: true, autocomplete: 'current-password' }, { name: 'newPassword', label: 'New password (8+ characters, letters and numbers)', type: 'password', required: true, autocomplete: 'new-password' }],
      onSubmit: async (v, form) => { await BL.api('/driver/profile', { method: 'PUT', body: v }); form.reset(); toast('Password updated'); },
    });
  }

  /* ---------- contact dispatch ---------- */
  async function contact(view) {
    let c = {}; try { c = await BL.api('/content'); } catch { /* optional */ }
    const wa = c.whatsapp ? `https://wa.me/${String(c.whatsapp).replace(/\D/g, '')}` : '';
    view.innerHTML = `<div class="panel" style="max-width:760px"><h2>Reach dispatch now</h2><p>For urgent loads, call or message us. We answer 24/7.</p><div class="actions">${c.phone ? `<a class="btn btn--primary" href="tel:${esc(c.phone.replace(/[^\d+]/g, ''))}">Call ${esc(c.phone)}</a>` : ''}${wa ? `<a class="btn btn--whatsapp" href="${wa}" target="_blank" rel="noopener">WhatsApp</a>` : ''}${c.email ? `<a class="btn btn--ghost" href="mailto:${esc(c.email)}">${esc(c.email)}</a>` : ''}</div></div>`;
    inlineForm(view, {
      title: 'Send a message', fields: [{ name: 'subject', label: 'Subject', full: true, placeholder: 'e.g. Question about LD-100012' }, { name: 'message', label: 'Message', type: 'textarea', required: true, full: true }],
      submit: 'Send to dispatch', onSubmit: async (v, form) => { await BL.api('/driver/messages', { method: 'POST', body: v }); form.reset(); toast('Message sent to dispatch'); },
    });
  }

  UI.initShell({ role: 'driver', views: { overview, loads, mine, truck, documents, profile, contact } });
})();
