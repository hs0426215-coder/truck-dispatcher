/* ==========================================================================
   ui.js - dashboard helpers: escaping, formatting, toast, modal forms, tables
   ========================================================================== */
(function () {
  const esc = (s = '') => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (n) => (n || n === 0 ? `$${Number(n).toLocaleString('en-US', { maximumFractionDigits: 0 })}` : '-');
  const date = (d) => (d ? new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' }) : '-');
  const dateInput = (d) => (d ? new Date(d).toISOString().slice(0, 10) : '');

  const EQUIP = { dry_van: 'Dry van', reefer: 'Reefer', flatbed: 'Flatbed', step_deck: 'Step deck' };
  const DOCS = { cdl: 'CDL', mc_authority: 'MC authority', insurance: 'Insurance certificate', w9: 'W-9', carrier_agreement: 'Carrier agreement', other: 'Other' };
  const STATUS_TONE = { available: 'info', requested: 'warn', booked: 'ok', in_transit: 'info', delivered: 'ok', cancelled: 'bad', pending: 'warn', approved: 'ok', suspended: 'bad', new: 'warn', read: 'info', replied: 'ok', active: 'ok', inactive: 'bad' };
  const badge = (s) => `<span class="badge badge--${STATUS_TONE[s] || ''}">${esc(String(s).replace('_', ' '))}</span>`;

  function toast(msg, type = 'ok') {
    const el = document.createElement('div'); el.className = `toast${type === 'err' ? ' toast--err' : ''}`; el.textContent = msg;
    document.getElementById('toast').appendChild(el); setTimeout(() => el.remove(), 3800);
  }

  // ---- Field builders ----
  function fieldHTML(f, v) {
    const val = v ?? f.value ?? '';
    const id = `f-${f.name}`; const req = f.required ? 'required' : '';
    let input;
    if (f.type === 'select') input = `<select id="${id}" name="${f.name}" ${req}>${(f.placeholder ? `<option value="">${esc(f.placeholder)}</option>` : '')}${f.options.map(([k, t]) => `<option value="${esc(k)}"${String(val) === String(k) ? ' selected' : ''}>${esc(t)}</option>`).join('')}</select>`;
    else if (f.type === 'textarea') input = `<textarea id="${id}" name="${f.name}" ${req}>${esc(val)}</textarea>`;
    else if (f.type === 'checkbox') input = `<select id="${id}" name="${f.name}"><option value="true"${val !== false ? ' selected' : ''}>Yes</option><option value="false"${val === false ? ' selected' : ''}>No</option></select>`;
    else input = `<input id="${id}" name="${f.name}" type="${f.type || 'text'}" value="${esc(val)}" ${req} ${f.step ? `step="${f.step}"` : ''} ${f.placeholder ? `placeholder="${esc(f.placeholder)}"` : ''} ${f.autocomplete ? `autocomplete="${f.autocomplete}"` : ''}>`;
    return `<div class="field${f.full ? ' field--full' : ''}"><label for="${id}">${esc(f.label)}</label>${input}<span class="field-error"></span></div>`;
  }

  // Read form values: numbers -> Number, empty -> undefined, checkbox selects -> boolean
  function readValues(form, fields) {
    const out = {};
    fields.forEach((f) => {
      let v = form.elements[f.name].value;
      if (f.type === 'checkbox') v = v === 'true';
      else if (v === '') v = f.keepEmpty ? '' : undefined;
      else if (f.type === 'number') v = Number(v);
      out[f.name] = v;
    });
    return out;
  }

  /* openForm({title, fields, values, submitLabel, onSubmit}) - modal with validation + server errors */
  function openForm({ title, fields, values = {}, submitLabel = 'Save', onSubmit, intro = '' }) {
    const root = document.getElementById('modalRoot');
    const bg = document.createElement('div'); bg.className = 'modal-bg';
    bg.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}"><h2>${esc(title)}</h2>${intro ? `<p>${intro}</p>` : ''}
      <form class="form form--2" novalidate>${fields.map((f) => fieldHTML(f, values[f.name])).join('')}
      <div class="field--full"><div class="alert" role="alert"></div></div>
      <div class="field--full modal__foot"><button type="button" class="btn btn--ghost" data-close>Cancel</button><button type="submit" class="btn btn--primary">${esc(submitLabel)}</button></div></form></div>`;
    root.appendChild(bg);
    const form = bg.querySelector('form'), alertBox = bg.querySelector('.alert');
    const close = () => { bg.remove(); document.removeEventListener('keydown', onKey); };
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', onKey);
    bg.addEventListener('mousedown', (e) => { if (e.target === bg) close(); });
    bg.querySelector('[data-close]').onclick = close;
    form.querySelector('input,select,textarea')?.focus();

    form.addEventListener('submit', async (e) => {
      e.preventDefault(); BL.clearErrors(form); BL.hideAlert(alertBox);
      let ok = true;
      fields.forEach((f) => { const el = form.elements[f.name]; if (f.required && !el.value.trim()) { BL.setFieldError(el, 'Required.'); ok = false; } });
      if (!ok) return;
      const btn = form.querySelector('[type=submit]'); btn.disabled = true;
      try { await onSubmit(readValues(form, fields)); close(); }
      catch (err) { BL.showServerErrors(form, err.errors); BL.showAlert(alertBox, 'err', err.message); btn.disabled = false; }
    });
  }

  function openInfo(title, html) {
    const root = document.getElementById('modalRoot');
    const bg = document.createElement('div'); bg.className = 'modal-bg';
    bg.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}"><h2>${esc(title)}</h2>${html}<div class="modal__foot"><button class="btn btn--primary" data-close>Close</button></div></div>`;
    root.appendChild(bg);
    const close = () => { bg.remove(); document.removeEventListener('keydown', onKey); };
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', onKey);
    bg.addEventListener('mousedown', (e) => { if (e.target === bg) close(); });
    bg.querySelector('[data-close]').onclick = close;
    return bg;
  }

  function confirmBox(message, confirmLabel = 'Delete') {
    return new Promise((resolve) => {
      const bg = openInfo('Please confirm', `<p>${esc(message)}</p>`);
      const foot = bg.querySelector('.modal__foot');
      foot.innerHTML = `<button class="btn btn--ghost" data-no>Cancel</button><button class="btn btn--danger" data-yes>${esc(confirmLabel)}</button>`;
      foot.querySelector('[data-no]').onclick = () => { bg.remove(); resolve(false); };
      foot.querySelector('[data-yes]').onclick = () => { bg.remove(); resolve(true); };
    });
  }

  // Simple table: columns [{label, render(row)}]
  function table(columns, rows, emptyText = 'Nothing here yet.') {
    if (!rows.length) return `<div class="table-wrap"><div class="empty">${esc(emptyText)}</div></div>`;
    return `<div class="table-wrap"><table><thead><tr>${columns.map((c) => `<th>${esc(c.label)}</th>`).join('')}</tr></thead><tbody>${rows.map((r, i) => `<tr data-i="${i}">${columns.map((c) => `<td>${c.render(r)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
  }

  const debounce = (fn, ms = 300) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  // Shared shell: auth guard, sidebar navigation, logout, hash routing
  function initShell({ role, views, defaultView = 'overview' }) {
    const user = BL.getUser();
    if (!BL.getToken() || !user || user.role !== role) { location.replace('login.html'); return; }
    document.getElementById('userBox').innerHTML = `<b>${esc(user.name)}</b>${esc(user.email)}`;
    document.getElementById('logoutBtn').onclick = () => { BL.clearSession(); location.href = 'login.html'; };
    const side = document.getElementById('sidebar'), toggle = document.getElementById('sideToggle');
    toggle.onclick = () => { const o = side.classList.toggle('open'); toggle.setAttribute('aria-expanded', o); };

    const titles = Object.fromEntries([...document.querySelectorAll('.side-link')].map((b) => [b.dataset.view, b.textContent]));
    async function go(name) {
      if (!views[name]) name = defaultView;
      document.querySelectorAll('.side-link').forEach((b) => b.classList.toggle('active', b.dataset.view === name));
      document.getElementById('viewTitle').textContent = titles[name];
      document.title = `${titles[name]} | BlueLine Dispatch`;
      side.classList.remove('open');
      // Swap in a fresh container so listeners from the previous view are dropped
      const old = document.getElementById('view'); const view = old.cloneNode(false); old.replaceWith(view);
      view.innerHTML = '<p class="muted">Loading...</p>';
      try { await views[name](view); } catch (err) { view.innerHTML = `<div class="alert alert--err show">${esc(err.message)}</div>`; }
    }
    document.querySelectorAll('.side-link').forEach((b) => b.addEventListener('click', () => { location.hash = b.dataset.view; }));
    window.addEventListener('hashchange', () => go(location.hash.slice(1)));
    go(location.hash.slice(1) || defaultView);
    return { go, refresh: () => go(location.hash.slice(1) || defaultView) };
  }

  window.UI = { fieldHTML, readValues, esc, money, date, dateInput, EQUIP, DOCS, badge, toast, openForm, openInfo, confirmBox, table, debounce, initShell };
})();
