// Creates the first admin account, default services and default website content.
// Safe to run repeatedly. Runs automatically on server start; also: `npm run seed`
const User = require('./models/User');
const Service = require('./models/Service');
const Content = require('./models/Content');

const SERVICES = [
  ['Dry Van Dispatching', 'Steady freight for 53-ft dry vans on the lanes that pay best.', 'van'],
  ['Reefer Dispatching', 'Temperature-controlled loads with rates that cover fuel and reefer costs.', 'snow'],
  ['Flatbed Dispatching', 'Steel, lumber and building materials matched to your flatbed.', 'flatbed'],
  ['Step Deck Dispatching', 'Tall and oversize freight with the right permits and routing.', 'stepdeck'],
  ['Load Booking', 'We search load boards and broker networks and book the loads for you.', 'clipboard'],
  ['Route Planning', 'Efficient routes that cut deadhead miles and keep you home on time.', 'route'],
  ['Rate Negotiation', 'We push brokers for higher rates so every mile pays more.', 'dollar'],
  ['Broker Communication', 'We handle calls, rate confirmations and paperwork with brokers.', 'chat'],
  ['24/7 Dispatch Support', 'A live dispatcher answers day or night, weekends included.', 'clock'],
];

const CONTENT = {
  heroTitle: 'Reliable Truck Dispatching Solutions Across America',
  heroSubtitle: 'We Keep Your Trucks Moving. You Focus on Growing Your Business.',
  phone: '+1 (555) 123-4567',
  email: 'dispatch@yourcompany.com',
  whatsapp: '15551234567',
  address: '1200 Commerce St, Dallas, TX 75202',
};

module.exports = async function seed() {
  if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
    const exists = await User.findOne({ email: process.env.ADMIN_EMAIL.toLowerCase() });
    if (!exists) {
      await User.create({ name: process.env.ADMIN_NAME || 'Dispatch Admin', email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD, role: 'admin', status: 'approved' });
      console.log(`Admin account created: ${process.env.ADMIN_EMAIL}`);
    }
  }
  if ((await Service.countDocuments()) === 0) {
    await Service.insertMany(SERVICES.map(([title, description, icon], i) => ({ title, description, icon, order: i })));
  }
  for (const [key, value] of Object.entries(CONTENT)) {
    await Content.updateOne({ key }, { $setOnInsert: { value } }, { upsert: true });
  }
};

// Allow `node seed.js`
if (require.main === module) {
  require('dotenv').config();
  require('./config/db')().then(() => module.exports()).then(() => { console.log('Seed complete.'); process.exit(0); })
    .catch((e) => { console.error(e); process.exit(1); });
}
