// express-validator rule sets + a runner that returns friendly errors
const { body, validationResult } = require('express-validator');

exports.validate = (req, res, next) => {
  const result = validationResult(req);
  if (result.isEmpty()) return next();
  const errors = result.array().map((e) => ({ field: e.path, message: e.msg }));
  return res.status(400).json({ message: errors[0].message, errors });
};

const phone = (field) => body(field).optional({ checkFalsy: true }).matches(/^[+()\-.\s\d]{7,20}$/).withMessage('Enter a valid phone number.');

exports.registerRules = [
  body('name').trim().isLength({ min: 2 }).withMessage('Enter your full name.'),
  body('email').isEmail().withMessage('Enter a valid email address.').normalizeEmail(),
  phone('phone'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters.')
    .matches(/[A-Za-z]/).withMessage('Password needs at least one letter.')
    .matches(/\d/).withMessage('Password needs at least one number.'),
];

exports.loginRules = [
  body('email').isEmail().withMessage('Enter a valid email address.').normalizeEmail(),
  body('password').notEmpty().withMessage('Enter your password.'),
];

exports.contactRules = [
  body('name').trim().isLength({ min: 2, max: 80 }).withMessage('Enter your name.'),
  body('email').isEmail().withMessage('Enter a valid email address.').normalizeEmail(),
  phone('phone'),
  body('subject').optional({ checkFalsy: true }).trim().isLength({ max: 120 }).withMessage('Subject is too long.'),
  body('message').trim().isLength({ min: 10, max: 3000 }).withMessage('Message must be between 10 and 3000 characters.'),
];

exports.loadRules = [
  body('origin').trim().notEmpty().withMessage('Origin is required.'),
  body('destination').trim().notEmpty().withMessage('Destination is required.'),
  body('pickupDate').isISO8601().withMessage('Enter a valid pickup date.'),
  body('equipment').isIn(['dry_van', 'reefer', 'flatbed', 'step_deck']).withMessage('Choose an equipment type.'),
  body('rate').isFloat({ min: 0 }).withMessage('Enter the rate in USD.'),
];
