// JWT authentication + role-based authorization
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');

// Requires a valid "Authorization: Bearer <token>" header
exports.protect = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: 'Please log in to continue.' });

  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    return res.status(401).json({ message: 'Your session has expired. Please log in again.' });
  }
  const user = await User.findById(decoded.id);
  if (!user) return res.status(401).json({ message: 'This account no longer exists.' });
  if (user.status === 'suspended') return res.status(403).json({ message: 'This account is suspended. Contact dispatch.' });
  req.user = user;
  next();
});

// Restrict a route to specific roles, e.g. authorize('admin')
exports.authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) return res.status(403).json({ message: 'You do not have access to this resource.' });
  next();
};
