// Multer config for driver document uploads (PDF / JPG / PNG, max 5 MB)
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');

const storage = multer.diskStorage({
  destination: path.join(__dirname, '..', 'uploads'),
  filename: (req, file, cb) => cb(null, `${crypto.randomBytes(16).toString('hex')}${path.extname(file.originalname).toLowerCase()}`),
});

const allowed = ['application/pdf', 'image/jpeg', 'image/png'];

module.exports = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (allowed.includes(file.mimetype)) return cb(null, true);
    const err = new Error('Only PDF, JPG or PNG files up to 5 MB are allowed.');
    err.status = 400;
    cb(err);
  },
});
