// 404 handler + centralized error handler
exports.notFound = (req, res) => res.status(404).json({ message: `Route not found: ${req.originalUrl}` });

exports.errorHandler = (err, req, res, next) => { // eslint-disable-line no-unused-vars
  let status = err.status || 500;
  let message = err.message || 'Server error';

  if (err.code === 11000) { status = 409; message = `That ${Object.keys(err.keyValue || {})[0] || 'value'} is already in use.`; }
  if (err.name === 'ValidationError') { status = 400; message = Object.values(err.errors).map((e) => e.message).join(' '); }
  if (err.name === 'CastError') { status = 400; message = 'Invalid ID.'; }
  if (err.name === 'MulterError') { status = 400; message = err.message; }

  if (status === 500) console.error(err);
  res.status(status).json({ message: status === 500 && process.env.NODE_ENV === 'production' ? 'Something went wrong on our side.' : message });
};
