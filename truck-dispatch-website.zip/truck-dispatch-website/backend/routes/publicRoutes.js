const router = require('express').Router();
const rateLimit = require('express-rate-limit');
const { submitContact, listServices, getContent } = require('../controllers/publicController');
const { contactRules, validate } = require('../middleware/validators');

const contactLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 10, message: { message: 'Too many messages. Please call or WhatsApp us instead.' } });

router.post('/contact', contactLimiter, contactRules, validate, submitContact);
router.get('/services', listServices);
router.get('/content', getContent);

module.exports = router;
