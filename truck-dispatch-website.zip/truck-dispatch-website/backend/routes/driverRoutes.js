const router = require('express').Router();
const c = require('../controllers/driverController');
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.use(protect, authorize('driver'));

router.put('/profile', c.updateProfile);
router.put('/truck', c.updateTruck);
router.post('/documents', upload.single('file'), c.uploadDocument);
router.delete('/documents/:docId', c.deleteDocument);
router.get('/documents/:docId/file', c.downloadDocument);
router.get('/loads', c.availableLoads);
router.post('/loads/:id/book', c.bookLoad);
router.get('/my-loads', c.myLoads);
router.post('/my-loads/:id/cancel', c.cancelRequest);
router.post('/messages', c.sendMessage);

module.exports = router;
