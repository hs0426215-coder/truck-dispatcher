const router = require('express').Router();
const admin = require('../controllers/adminController');
const loads = require('../controllers/loadController');
const crud = require('../utils/crudFactory');
const Customer = require('../models/Customer');
const Service = require('../models/Service');
const { protect, authorize } = require('../middleware/auth');
const { loadRules, validate } = require('../middleware/validators');

// Every admin route requires a valid token AND the admin role
router.use(protect, authorize('admin'));

router.get('/stats', admin.stats);

// Drivers
router.get('/drivers', admin.listDrivers);
router.patch('/drivers/:id', admin.updateDriver);
router.delete('/drivers/:id', admin.deleteDriver);
router.get('/drivers/:id/documents/:docId', admin.downloadDriverDocument);

// Loads
router.get('/loads', loads.list);
router.post('/loads', loadRules, validate, loads.create);
router.put('/loads/:id', loads.update);
router.delete('/loads/:id', loads.remove);

// Customers
const customers = crud(Customer, { searchFields: ['name', 'company', 'email'], label: 'Customer' });
router.get('/customers', customers.list);
router.post('/customers', customers.create);
router.put('/customers/:id', customers.update);
router.delete('/customers/:id', customers.remove);

// Messages / inquiries
router.get('/inquiries', admin.listInquiries);
router.patch('/inquiries/:id', admin.updateInquiry);
router.delete('/inquiries/:id', admin.deleteInquiry);

// Dispatch services
const services = crud(Service, { sort: 'order', label: 'Service' });
router.get('/services', services.list);
router.post('/services', services.create);
router.put('/services/:id', services.update);
router.delete('/services/:id', services.remove);

// Website content
router.get('/content', admin.getContent);
router.put('/content', admin.updateContent);

module.exports = router;
