// BlueLine Dispatch - Express server (API + static frontend)
require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const connectDB = require('./config/db');
const seed = require('./seed');
const { notFound, errorHandler } = require('./middleware/error');

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 16) {
  console.error('Set a JWT_SECRET of at least 16 characters in backend/.env');
  process.exit(1);
}

const app = express();

// --- Security & parsing ---
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:'],
      frameSrc: ['https://www.google.com', 'https://maps.google.com'],
      connectSrc: ["'self'"],
      upgradeInsecureRequests: null,   // keep http://localhost working in development; enable behind HTTPS
    },
  },
}));
app.use(cors({ origin: process.env.CLIENT_URL || true }));
app.use(express.json({ limit: '1mb' }));
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, max: 600 }));

// --- API routes ---
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/driver', require('./routes/driverRoutes'));
app.use('/api/admin', require('./routes/adminRoutes'));
app.use('/api', require('./routes/publicRoutes'));
app.use('/api', notFound);

// --- Static frontend (uploads are NOT served statically; they need an authenticated route) ---
app.use(express.static(path.join(__dirname, '..', 'frontend'), { extensions: ['html'], maxAge: '1h' }));

app.use(errorHandler);

const PORT = process.env.PORT || 5000;
connectDB()
  .then(seed)
  .then(() => app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`)))
  .catch((err) => { console.error('Startup failed:', err.message); process.exit(1); });
