// Public endpoints: contact form, services list, editable site content
const Inquiry = require('../models/Inquiry');
const Service = require('../models/Service');
const Content = require('../models/Content');
const asyncHandler = require('../utils/asyncHandler');
const { sendMail, esc } = require('../utils/mailer');

// POST /api/contact
exports.submitContact = asyncHandler(async (req, res) => {
  const { name, email, phone, subject, message } = req.body;
  const inquiry = await Inquiry.create({ name, email, phone, subject, message, source: 'website' });

  // Notify the dispatch team + auto-reply to the sender
  sendMail({
    to: process.env.NOTIFY_EMAIL,
    replyTo: email,
    subject: `New website inquiry: ${inquiry.subject}`,
    html: `<p><b>${esc(name)}</b> (${esc(email)}${phone ? `, ${esc(phone)}` : ''})</p><p>${esc(message).replace(/\n/g, '<br>')}</p>`,
  });
  sendMail({
    to: email,
    subject: 'We received your message',
    html: `<p>Hi ${esc(name)},</p><p>Thanks for contacting BlueLine Dispatch. A dispatcher will reply shortly. For urgent loads, call or WhatsApp us any time.</p>`,
  });

  res.status(201).json({ message: 'Thanks! Your message is in. A dispatcher will reply shortly.' });
});

// GET /api/services
exports.listServices = asyncHandler(async (req, res) => {
  res.json(await Service.find({ active: true }).sort('order'));
});

// GET /api/content  ->  { key: value, ... }
exports.getContent = asyncHandler(async (req, res) => {
  const rows = await Content.find();
  res.json(Object.fromEntries(rows.map((r) => [r.key, r.value])));
});
