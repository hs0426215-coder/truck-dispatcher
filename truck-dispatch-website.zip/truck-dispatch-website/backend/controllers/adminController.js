// Admin-only: stats, drivers, messages, site content
const fs = require('fs');
const path = require('path');
const User = require('../models/User');
const Load = require('../models/Load');
const Inquiry = require('../models/Inquiry');
const Customer = require('../models/Customer');
const Content = require('../models/Content');
const asyncHandler = require('../utils/asyncHandler');
const { sendMail, esc } = require('../utils/mailer');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');

// GET /api/admin/stats
exports.stats = asyncHandler(async (req, res) => {
  const [drivers, pendingDrivers, loads, availableLoads, activeLoads, delivered, customers, newMessages, revenue, recentLoads, recentDrivers] = await Promise.all([
    User.countDocuments({ role: 'driver' }),
    User.countDocuments({ role: 'driver', status: 'pending' }),
    Load.countDocuments(),
    Load.countDocuments({ status: 'available' }),
    Load.countDocuments({ status: { $in: ['requested', 'booked', 'in_transit'] } }),
    Load.countDocuments({ status: 'delivered' }),
    Customer.countDocuments(),
    Inquiry.countDocuments({ status: 'new' }),
    Load.aggregate([{ $match: { status: 'delivered' } }, { $group: { _id: null, total: { $sum: '$rate' } } }]),
    Load.find().sort('-createdAt').limit(5).select('loadNumber origin destination status rate'),
    User.find({ role: 'driver' }).sort('-createdAt').limit(5).select('name email status createdAt'),
  ]);
  res.json({ drivers, pendingDrivers, loads, availableLoads, activeLoads, delivered, customers, newMessages, deliveredRevenue: revenue[0]?.total || 0, recentLoads, recentDrivers });
});

// GET /api/admin/drivers
exports.listDrivers = asyncHandler(async (req, res) => {
  const filter = { role: 'driver' };
  if (req.query.status) filter.status = req.query.status;
  if (req.query.q) {
    const rx = new RegExp(String(req.query.q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    filter.$or = [{ name: rx }, { email: rx }, { companyName: rx }, { mcNumber: rx }];
  }
  res.json(await User.find(filter).sort('-createdAt').limit(500));
});

// PATCH /api/admin/drivers/:id  { status }
exports.updateDriver = asyncHandler(async (req, res) => {
  const driver = await User.findOne({ _id: req.params.id, role: 'driver' });
  if (!driver) return res.status(404).json({ message: 'Driver not found.' });
  if (!['pending', 'approved', 'suspended'].includes(req.body.status)) return res.status(400).json({ message: 'Invalid status.' });
  const changed = driver.status !== req.body.status;
  driver.status = req.body.status;
  await driver.save();
  if (changed && driver.status === 'approved') {
    sendMail({ to: driver.email, subject: 'Your BlueLine Dispatch account is approved', html: `<p>Hi ${esc(driver.name)}, you are approved. Log in to browse and book loads.</p>` });
  }
  res.json(driver);
});

// DELETE /api/admin/drivers/:id
exports.deleteDriver = asyncHandler(async (req, res) => {
  const driver = await User.findOneAndDelete({ _id: req.params.id, role: 'driver' });
  if (!driver) return res.status(404).json({ message: 'Driver not found.' });
  driver.documents.forEach((d) => fs.unlink(path.join(UPLOAD_DIR, d.filename), () => {}));
  await Load.updateMany({ bookedBy: driver._id, status: { $in: ['requested', 'booked'] } }, { status: 'available', bookedBy: null });
  res.json({ message: 'Driver deleted.' });
});

// GET /api/admin/drivers/:id/documents/:docId
exports.downloadDriverDocument = asyncHandler(async (req, res) => {
  const driver = await User.findById(req.params.id);
  const doc = driver && driver.documents.id(req.params.docId);
  if (!doc) return res.status(404).json({ message: 'Document not found.' });
  res.download(path.join(UPLOAD_DIR, doc.filename), doc.originalName);
});

// ---- Customer inquiries / messages ----
exports.listInquiries = asyncHandler(async (req, res) => {
  const filter = req.query.status ? { status: req.query.status } : {};
  res.json(await Inquiry.find(filter).sort('-createdAt').limit(300));
});
exports.updateInquiry = asyncHandler(async (req, res) => {
  if (!['new', 'read', 'replied'].includes(req.body.status)) return res.status(400).json({ message: 'Invalid status.' });
  const doc = await Inquiry.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  if (!doc) return res.status(404).json({ message: 'Message not found.' });
  res.json(doc);
});
exports.deleteInquiry = asyncHandler(async (req, res) => {
  await Inquiry.findByIdAndDelete(req.params.id);
  res.json({ message: 'Message deleted.' });
});

// ---- Editable website content ----
exports.getContent = asyncHandler(async (req, res) => {
  const rows = await Content.find();
  res.json(Object.fromEntries(rows.map((r) => [r.key, r.value])));
});
exports.updateContent = asyncHandler(async (req, res) => {
  const entries = Object.entries(req.body || {}).filter(([k, v]) => /^[a-zA-Z0-9_]{1,40}$/.test(k) && typeof v === 'string' && v.length <= 1000);
  await Promise.all(entries.map(([key, value]) => Content.findOneAndUpdate({ key }, { value }, { upsert: true, new: true })));
  res.json({ message: 'Website content updated.' });
});
