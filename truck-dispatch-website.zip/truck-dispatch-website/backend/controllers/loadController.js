// Admin load management (CRUD from the factory, plus status side-effects)
const Load = require('../models/Load');
const User = require('../models/User');
const crud = require('../utils/crudFactory');
const asyncHandler = require('../utils/asyncHandler');
const { sendMail, esc } = require('../utils/mailer');

const base = crud(Load, { searchFields: ['loadNumber', 'origin', 'destination', 'broker'], populate: { path: 'bookedBy', select: 'name email phone' }, label: 'Load' });

exports.list = base.list;
exports.create = base.create;
exports.remove = base.remove;

// Whitelist fields so clients cannot overwrite internals
const EDITABLE = ['origin', 'destination', 'pickupDate', 'deliveryDate', 'equipment', 'weightLbs', 'miles', 'rate', 'commodity', 'broker', 'notes', 'status', 'bookedBy'];

exports.update = asyncHandler(async (req, res) => {
  const load = await Load.findById(req.params.id);
  if (!load) return res.status(404).json({ message: 'Load not found.' });
  const previous = load.status;

  EDITABLE.forEach((k) => { if (req.body[k] !== undefined) load[k] = req.body[k] === '' ? undefined : req.body[k]; });
  if (['available', 'cancelled'].includes(load.status) && req.body.status) load.bookedBy = null;
  await load.save();

  // Tell the driver when their booking status changes
  if (load.bookedBy && load.status !== previous) {
    const driver = await User.findById(load.bookedBy);
    if (driver) {
      sendMail({
        to: driver.email,
        subject: `Load ${load.loadNumber} is now ${load.status.replace('_', ' ')}`,
        html: `<p>Hi ${esc(driver.name)},</p><p>${esc(load.loadNumber)} (${esc(load.origin)} to ${esc(load.destination)}) is now <b>${esc(load.status.replace('_', ' '))}</b>.</p>`,
      });
    }
  }
  res.json(await load.populate({ path: 'bookedBy', select: 'name email phone' }));
});
