// Everything a logged-in driver can do
const fs = require('fs');
const path = require('path');
const Load = require('../models/Load');
const Inquiry = require('../models/Inquiry');
const asyncHandler = require('../utils/asyncHandler');
const { sendMail, esc } = require('../utils/mailer');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');

// PUT /api/driver/profile
exports.updateProfile = asyncHandler(async (req, res) => {
  const fields = ['name', 'phone', 'companyName', 'mcNumber', 'dotNumber', 'address'];
  fields.forEach((f) => { if (req.body[f] !== undefined) req.user[f] = String(req.body[f]).trim(); });
  if (req.body.newPassword) {
    if (req.body.newPassword.length < 8 || !/\d/.test(req.body.newPassword) || !/[A-Za-z]/.test(req.body.newPassword)) {
      return res.status(400).json({ message: 'New password needs 8+ characters with letters and numbers.' });
    }
    const withPw = await req.user.constructor.findById(req.user._id).select('+password');
    if (!req.body.currentPassword || !(await withPw.matchPassword(req.body.currentPassword))) {
      return res.status(400).json({ message: 'Current password is incorrect.' });
    }
    withPw.password = req.body.newPassword;
    await withPw.save();
  }
  await req.user.save();
  res.json(req.user);
});

// PUT /api/driver/truck
exports.updateTruck = asyncHandler(async (req, res) => {
  const t = req.body;
  const allowed = ['type', 'make', 'model', 'year', 'plate', 'vin', 'capacityLbs', 'trailerLengthFt', 'preferredLanes'];
  allowed.forEach((k) => { if (t[k] !== undefined && t[k] !== '') req.user.truck[k] = t[k]; });
  if (!['dry_van', 'reefer', 'flatbed', 'step_deck'].includes(req.user.truck.type)) {
    return res.status(400).json({ message: 'Choose your equipment type.' });
  }
  await req.user.save();
  res.json(req.user);
});

// POST /api/driver/documents   (multipart: file + type)
exports.uploadDocument = asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'Choose a PDF, JPG or PNG file to upload.' });
  const type = req.body.type;
  if (!['cdl', 'mc_authority', 'insurance', 'w9', 'carrier_agreement', 'other'].includes(type)) {
    fs.unlink(req.file.path, () => {});
    return res.status(400).json({ message: 'Choose a document type.' });
  }
  req.user.documents.push({ type, filename: req.file.filename, originalName: req.file.originalname });
  await req.user.save();
  sendMail({ to: process.env.NOTIFY_EMAIL, subject: `Document uploaded by ${req.user.name}`, html: `<p>${esc(req.user.name)} uploaded: ${esc(type)}.</p>` });
  res.status(201).json(req.user);
});

// DELETE /api/driver/documents/:docId
exports.deleteDocument = asyncHandler(async (req, res) => {
  const doc = req.user.documents.id(req.params.docId);
  if (!doc) return res.status(404).json({ message: 'Document not found.' });
  fs.unlink(path.join(UPLOAD_DIR, doc.filename), () => {});
  doc.deleteOne();
  await req.user.save();
  res.json(req.user);
});

// GET /api/driver/documents/:docId/file   (owner only; admins use the admin route)
exports.downloadDocument = asyncHandler(async (req, res) => {
  const doc = req.user.documents.id(req.params.docId);
  if (!doc) return res.status(404).json({ message: 'Document not found.' });
  res.download(path.join(UPLOAD_DIR, doc.filename), doc.originalName);
});

// GET /api/driver/loads  - available loads, optionally filtered by equipment
exports.availableLoads = asyncHandler(async (req, res) => {
  const filter = { status: 'available' };
  if (req.query.equipment) filter.equipment = req.query.equipment;
  // Do not expose the broker name until a load is booked
  res.json(await Load.find(filter).select('-broker -bookedBy').sort('pickupDate').limit(200));
});

// POST /api/driver/loads/:id/book  - request a load (admin confirms)
exports.bookLoad = asyncHandler(async (req, res) => {
  if (req.user.status !== 'approved') return res.status(403).json({ message: 'Your account must be approved before you can book loads.' });
  // Atomic update prevents two drivers from taking the same load
  const load = await Load.findOneAndUpdate(
    { _id: req.params.id, status: 'available' },
    { status: 'requested', bookedBy: req.user._id },
    { new: true },
  );
  if (!load) return res.status(409).json({ message: 'Sorry, this load was just taken.' });
  sendMail({
    to: process.env.NOTIFY_EMAIL,
    subject: `Booking request: ${load.loadNumber}`,
    html: `<p>${esc(req.user.name)} requested ${esc(load.loadNumber)} (${esc(load.origin)} to ${esc(load.destination)}). Confirm it in the admin dashboard.</p>`,
  });
  res.json(load);
});

// GET /api/driver/my-loads
exports.myLoads = asyncHandler(async (req, res) => {
  res.json(await Load.find({ bookedBy: req.user._id }).sort('-updatedAt'));
});

// POST /api/driver/my-loads/:id/cancel  - driver withdraws a pending request
exports.cancelRequest = asyncHandler(async (req, res) => {
  const load = await Load.findOneAndUpdate(
    { _id: req.params.id, bookedBy: req.user._id, status: 'requested' },
    { status: 'available', bookedBy: null },
    { new: true },
  );
  if (!load) return res.status(400).json({ message: 'Only pending requests can be withdrawn.' });
  res.json(load);
});

// POST /api/driver/messages  - message the dispatch team
exports.sendMessage = asyncHandler(async (req, res) => {
  const { subject, message } = req.body;
  if (!message || message.trim().length < 5) return res.status(400).json({ message: 'Write a message for dispatch.' });
  await Inquiry.create({
    name: req.user.name, email: req.user.email, phone: req.user.phone,
    subject: subject || 'Driver message', message, source: 'driver', user: req.user._id,
  });
  sendMail({ to: process.env.NOTIFY_EMAIL, replyTo: req.user.email, subject: `Driver message: ${subject || req.user.name}`, html: `<p>${esc(message)}</p>` });
  res.status(201).json({ message: 'Message sent. Dispatch will reply by email or phone.' });
});
