// Registration, login and "who am I"
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const { sendMail, esc } = require('../utils/mailer');

const signToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

const publicUser = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role, status: u.status });

// POST /api/auth/register  (public registration always creates a driver)
exports.register = asyncHandler(async (req, res) => {
  const { name, email, phone, password, companyName, mcNumber, dotNumber } = req.body;
  if (await User.findOne({ email })) return res.status(409).json({ message: 'An account with that email already exists. Try logging in.' });

  const user = await User.create({ name, email, phone, password, companyName, mcNumber, dotNumber, role: 'driver' });

  sendMail({
    to: user.email,
    subject: 'Welcome to BlueLine Dispatch',
    html: `<p>Hi ${esc(user.name)},</p><p>Your driver account is created. Upload your documents from the driver dashboard and our team will approve your account so you can start booking loads.</p>`,
  });
  sendMail({
    to: process.env.NOTIFY_EMAIL,
    subject: `New driver registered: ${user.name}`,
    html: `<p>${esc(user.name)} (${esc(user.email)}) registered${user.mcNumber ? ` - MC ${esc(user.mcNumber)}` : ''}.</p>`,
  });

  res.status(201).json({ token: signToken(user._id), user: publicUser(user) });
});

// POST /api/auth/login
exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).select('+password');
  // Same message for unknown email and wrong password, so accounts cannot be probed
  if (!user || !(await user.matchPassword(password))) return res.status(401).json({ message: 'Incorrect email or password.' });
  if (user.status === 'suspended') return res.status(403).json({ message: 'This account is suspended. Contact dispatch.' });
  res.json({ token: signToken(user._id), user: publicUser(user) });
});

// GET /api/auth/me
exports.me = asyncHandler(async (req, res) => res.json(req.user));
