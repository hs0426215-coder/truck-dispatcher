// Freight loads managed by admin and booked by drivers
const mongoose = require('mongoose');

const loadSchema = new mongoose.Schema({
  loadNumber: { type: String, unique: true, index: true },
  origin: { type: String, required: true, trim: true },
  destination: { type: String, required: true, trim: true },
  pickupDate: { type: Date, required: true },
  deliveryDate: Date,
  equipment: { type: String, enum: ['dry_van', 'reefer', 'flatbed', 'step_deck'], required: true },
  weightLbs: Number,
  miles: Number,
  rate: { type: Number, required: true, min: 0 },   // total, USD
  commodity: String,
  broker: String,
  notes: String,
  status: { type: String, enum: ['available', 'requested', 'booked', 'in_transit', 'delivered', 'cancelled'], default: 'available' },
  bookedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
}, { timestamps: true });

// Auto-generate a readable load number such as LD-100001
loadSchema.pre('validate', async function (next) {
  if (!this.loadNumber) {
    const last = await mongoose.model('Load').findOne().sort({ createdAt: -1 }).select('loadNumber');
    const n = last ? parseInt(last.loadNumber.replace(/\D/g, ''), 10) + 1 : 100001;
    this.loadNumber = `LD-${n}`;
  }
  next();
});

module.exports = mongoose.model('Load', loadSchema);
