// Users: drivers (carriers) and admins. Truck info and uploaded documents live on the driver.
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const documentSchema = new mongoose.Schema({
  type: { type: String, enum: ['cdl', 'mc_authority', 'insurance', 'w9', 'carrier_agreement', 'other'], required: true },
  filename: String,        // stored name on disk
  originalName: String,
  uploadedAt: { type: Date, default: Date.now },
});

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  phone: { type: String, trim: true },
  password: { type: String, required: true, minlength: 8, select: false },
  role: { type: String, enum: ['driver', 'admin'], default: 'driver' },
  status: { type: String, enum: ['pending', 'approved', 'suspended'], default: 'pending' },
  companyName: { type: String, trim: true },
  mcNumber: { type: String, trim: true },
  dotNumber: { type: String, trim: true },
  address: { type: String, trim: true },
  truck: {
    type: { type: String, enum: ['dry_van', 'reefer', 'flatbed', 'step_deck', ''], default: '' },
    make: String, model: String, year: Number,
    plate: String, vin: String,
    capacityLbs: Number, trailerLengthFt: Number,
    preferredLanes: String,
  },
  documents: [documentSchema],
}, { timestamps: true });

// Hash the password whenever it changes
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.matchPassword = function (plain) {
  return bcrypt.compare(plain, this.password);
};

module.exports = mongoose.model('User', userSchema);
