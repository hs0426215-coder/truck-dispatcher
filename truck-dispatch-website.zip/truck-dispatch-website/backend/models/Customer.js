// Brokers / shippers / carriers the company works with
const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  company: { type: String, trim: true },
  email: { type: String, lowercase: true, trim: true },
  phone: { type: String, trim: true },
  type: { type: String, enum: ['broker', 'shipper', 'carrier'], default: 'broker' },
  status: { type: String, enum: ['active', 'inactive'], default: 'active' },
  notes: String,
}, { timestamps: true });

module.exports = mongoose.model('Customer', customerSchema);
