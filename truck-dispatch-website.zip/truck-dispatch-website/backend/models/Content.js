// Editable website content (hero text, contact details, ...) stored as key/value pairs
const mongoose = require('mongoose');

const contentSchema = new mongoose.Schema({
  key: { type: String, required: true, unique: true },
  value: { type: String, default: '' },
}, { timestamps: true });

module.exports = mongoose.model('Content', contentSchema);
