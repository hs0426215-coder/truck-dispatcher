// Email notifications. Falls back to console logging when SMTP is not configured.
const nodemailer = require('nodemailer');

let transporter = null;
if (process.env.SMTP_HOST) {
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT) || 587,
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
  });
}

// Escape user input before placing it in HTML emails
exports.esc = (s = '') => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// Never throws: a failed email must not break the request that triggered it
exports.sendMail = async ({ to, subject, html, replyTo }) => {
  if (!to) return;
  const from = process.env.MAIL_FROM || 'BlueLine Dispatch <no-reply@localhost>';
  if (!transporter) { console.log(`[email skipped - SMTP not configured] to=${to} subject="${subject}"`); return; }
  try { await transporter.sendMail({ from, to, subject, html, replyTo }); }
  catch (e) { console.error('Email failed:', e.message); }
};
