// Small helper that builds list / get / create / update / delete handlers for a model
const asyncHandler = require('./asyncHandler');

module.exports = (Model, { searchFields = [], populate = '', sort = '-createdAt', label = 'Item' } = {}) => ({
  list: asyncHandler(async (req, res) => {
    const { q, status, equipment } = req.query;
    const filter = {};
    if (status) filter.status = status;
    if (equipment) filter.equipment = equipment;
    if (q && searchFields.length) {
      const rx = new RegExp(String(q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      filter.$or = searchFields.map((f) => ({ [f]: rx }));
    }
    let query = Model.find(filter).sort(sort).limit(500);
    if (populate) query = query.populate(populate);
    const items = await query;
    res.json(items);
  }),
  create: asyncHandler(async (req, res) => {
    res.status(201).json(await Model.create(req.body));
  }),
  update: asyncHandler(async (req, res) => {
    const doc = await Model.findById(req.params.id);
    if (!doc) return res.status(404).json({ message: `${label} not found.` });
    doc.set(req.body);
    await doc.save();
    res.json(doc);
  }),
  remove: asyncHandler(async (req, res) => {
    const doc = await Model.findByIdAndDelete(req.params.id);
    if (!doc) return res.status(404).json({ message: `${label} not found.` });
    res.json({ message: `${label} deleted.` });
  }),
});
